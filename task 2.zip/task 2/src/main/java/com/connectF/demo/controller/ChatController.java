package com.connectF.demo.controller;

import com.connectF.demo.dto.ChatRequest;
import com.connectF.demo.dto.ChatResponse;
import com.connectF.demo.model.Intent;
import com.connectF.demo.service.IntentService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class ChatController {

    private final IntentService intentService;

    public ChatController(IntentService intentService) {
        this.intentService = intentService;
    }

    @GetMapping("/intents/count")
    public Map<String, Integer> getIntentCount() {
        return Map.of("count", intentService.getIntentCount());
    }

    @PostMapping("/chat")
    public ChatResponse chat(@RequestBody ChatRequest request) {
        var match = intentService.findBestMatch(request.getMessage());

        if (match == null) {
            return new ChatResponse(
                    "I haven't been trained on that yet — try asking something else.",
                    "unknown",
                    0.0
            );
        }

        Intent intent = match.getKey();
        double score = match.getValue();
        return new ChatResponse(intentService.randomResponse(intent), intent.getTag(), score);
    }
}