
    package com.connectF.demo.dto;

    public class ChatResponse {
        private String reply;
        private String tag;
        private double confidence;

        public ChatResponse(String reply, String tag, double confidence) {
            this.reply = reply;
            this.tag = tag;
            this.confidence = confidence;
        }

        public String getReply() { return reply; }
        public String getTag() { return tag; }
        public double getConfidence() { return confidence; }
    }

