package com.connectF.demo.service;

import com.connectF.demo.model.Intent;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.*;

@Service
public class IntentService {

    private List<Intent> intents = new ArrayList<>();
    private static final double MATCH_THRESHOLD = 0.2;

    @PostConstruct
    public void loadIntents() {
        try (InputStream is = new ClassPathResource("intents.json").getInputStream()) {
            ObjectMapper mapper = new ObjectMapper();
            intents = Arrays.asList(mapper.readValue(is, Intent[].class));
        } catch (Exception e) {
            throw new RuntimeException("Could not load intents.json", e);
        }
    }

    public int getIntentCount() {
        return intents.size();
    }

    private List<String> tokenize(String sentence) {
        return Arrays.stream(sentence.toLowerCase().replaceAll("[^a-z0-9\\s]", "").split("\\s+"))
                .filter(s -> !s.isBlank())
                .toList();
    }

    public Map.Entry<Intent, Double> findBestMatch(String message) {
        Set<String> inputTokens = new HashSet<>(tokenize(message));
        Intent bestIntent = null;
        double bestScore = 0;

        for (Intent intent : intents) {
            for (String pattern : intent.getPatterns()) {
                List<String> patternTokens = tokenize(pattern);
                if (patternTokens.isEmpty()) continue;
                long overlap = patternTokens.stream().filter(inputTokens::contains).count();
                double score = (double) overlap / patternTokens.size();
                if (score > bestScore) {
                    bestScore = score;
                    bestIntent = intent;
                }
            }
        }

        if (bestIntent == null || bestScore < MATCH_THRESHOLD) return null;
        return Map.entry(bestIntent, bestScore);
    }

    public String randomResponse(Intent intent) {
        List<String> responses = intent.getResponses();
        return responses.get(new Random().nextInt(responses.size()));
    }
}